# Facebook Auto Blog Poster using Selenium

## Description
This script automates logging into Facebook and posting a status update using Selenium.

## ⚠️ Important
- This is for educational use only.
- DO NOT use your personal Facebook account.
- Use a dummy/test account to avoid violating Facebook's policy.

## Requirements
- Python
- Selenium
- ChromeDriver

## How to Run
1. Replace email and password in the script with your test account credentials.
2. Install Selenium:
   pip install selenium
3. Run the script:
   python fb_auto_post.py
