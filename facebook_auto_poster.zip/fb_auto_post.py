from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# NOTE: Replace these with valid credentials for testing (use a dummy account)
EMAIL = "your_email@example.com"
PASSWORD = "your_password"
MESSAGE = "This is an automated post using Selenium for my project!"

def facebook_auto_post():
    driver = webdriver.Chrome()
    driver.get("https://www.facebook.com/")

    time.sleep(3)

    email_input = driver.find_element(By.ID, "email")
    email_input.send_keys(EMAIL)

    password_input = driver.find_element(By.ID, "pass")
    password_input.send_keys(PASSWORD)
    password_input.send_keys(Keys.RETURN)

    time.sleep(5)

    try:
        # Create Post
        post_area = driver.find_element(By.XPATH, "//div[@aria-label='Create a post']")
        post_area.click()

        time.sleep(3)

        active_area = driver.find_element(By.XPATH, "//div[@role='textbox']")
        active_area.send_keys(MESSAGE)

        time.sleep(2)

        post_button = driver.find_element(By.XPATH, "//div[@aria-label='Post']")
        post_button.click()

        print("Post submitted successfully.")
    except Exception as e:
        print("Could not post:", e)

    time.sleep(5)
    driver.quit()

if __name__ == "__main__":
    facebook_auto_post()
